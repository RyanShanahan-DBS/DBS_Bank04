﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Collections.Specialized;

namespace DBS_Bank
{
    /// <summary>
    /// Interaction logic for AddAccount.xaml
    /// </summary>
    public partial class AddAccount : Window
    {
        public AddAccount()
        {
            InitializeComponent();
        }
        public string sourceC = ConfigurationManager.AppSettings.Get("Key0");


        private void AddAccount_Load(object sender, RoutedEventArgs e)
        {

            cboCounty.ItemsSource = Enum.GetValues((typeof(Counties)));

        }
        //If Savings radio button is selected. Show relevant info and hide irrelevant info
        private void rdoAccTypeSavings_Checked(object sender, RoutedEventArgs e)
        {
            //show pay. Hide Student number
            string at = "Savings";

            // Disable overdraft Limit
            lblOverdraftLim.IsEnabled = false;
            txtOverdraftLim.IsEnabled = false;

            //int overdraftLim = 0;

            //Hide overdraft Limit
            lblOverdraftLim.Visibility = Visibility.Hidden;
            txtOverdraftLim.Visibility = Visibility.Hidden;

        }

        private void rdoAccTypeCurrent_Checked(object sender, RoutedEventArgs e)
        {
            //show pay. Hide Student number
            string at = "Current";

            // Enable overdraft Limit
            lblOverdraftLim.IsEnabled = true;
            txtOverdraftLim.IsEnabled = true;

            // Disable overdraft Limit
            lblOverdraftLim.Visibility = Visibility.Visible;
            txtOverdraftLim.Visibility = Visibility.Visible;
        }

        
        private void btnAddAccount_Click(object sender, RoutedEventArgs e)
        {
            //variables
            string fn = txtFN1.Text;
            string sn = txtSN1.Text;
            string em = txtEmail.Text;
            string pn = txtPhone.Text;
            string al1 = txtAddressLine1.Text;
            string al2 = txtAddressLine2.Text;
            string an = txtAccNum.Text;
            string cty = txtCity.Text;
            string cy = cboCounty.SelectedItem.ToString();


            decimal ib = decimal.Parse(txtInitialBal.Text);
            int sc = int.Parse(sourceC);

            //MessageBox.Show("The value of Key0:" + sourceC);


        }

        private void btnMainMenu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow dashboard = new MainWindow();
            dashboard.Show();
            this.Close();
        }

        private void cboCounty_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
