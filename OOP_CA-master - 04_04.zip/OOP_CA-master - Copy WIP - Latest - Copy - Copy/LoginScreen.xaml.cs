﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace DBS_Bank
{
    /// <summary>
    /// Interaction logic for LoginScreen.xaml
    /// </summary>
    /// 
    
    public partial class LoginScreen : Window
    {
        public LoginScreen()
        {
            InitializeComponent();
        }
        //On submit button clicked
        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {

            HashCode HC = new HashCode();
            
            try
            {

                string username = txtUserName.Text;
                string password = PBpass.Password;

                //HC.PassHash(txtPass.Text);

                if (username == "Damien" && password == "Admin123")
                {
                    MainWindow dashboard = new MainWindow();
                    dashboard.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("UserName or Password is incorrect");
                }

            }
            catch(Exception)
            {
                MessageBox.Show("");
            }

        }
    }
}
