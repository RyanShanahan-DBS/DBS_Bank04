﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DBS_Bank
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnMainNewAcount_Click(object sender, RoutedEventArgs e)
        {
            AddAccount AddNewAccount = new AddAccount();
            AddNewAccount.Show();
            this.Close();
        }

        private void btnMainEditAccount_Click(object sender, RoutedEventArgs e)
        {
            EditAccount EditOldAccount = new EditAccount();
            EditOldAccount.Show();
            this.Close();
        }

        private void btnMainDepositFunds_Click(object sender, RoutedEventArgs e)
        {
            DepositFunds DepFunds = new DepositFunds();
            DepFunds.Show();
            this.Close();
        }

        private void btnMainWithdrawFunds_Click(object sender, RoutedEventArgs e)
        {
            WithdrawFunds WFunds = new WithdrawFunds();
            WFunds.Show();
            this.Close();
        }

        private void btnMainTransferFunds_Click(object sender, RoutedEventArgs e)
        {
            Transfer_Funds TFunds = new Transfer_Funds();
            TFunds.Show();
            this.Close();
        }

        private void btnMainViewTransactions_Click(object sender, RoutedEventArgs e)
        {
            ViewTransactions VTransactions = new ViewTransactions();
            VTransactions.Show();
            this.Close();
        }
    }
}
